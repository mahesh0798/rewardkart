const submit = document.getElementById("submit");
const add = document.getElementById("add");
const username = document.getElementById("username");
const Fullname = document.getElementById("name");
const Phonenumber = document.getElementById("Phonenumber");
const date = document.getElementById("date");
const emailaddress = document.getElementById("email");

submit.addEventListener("click", (e) => {
  e.preventDefault();
  var usernameValue = username.value;
  var letters = /^[A-Za-z]+$/;
  if (usernameValue === "" || !usernameValue.match(letters)) {
    alert("Username Cannot Be Blank");
  }
  var gender = form.querySelectorAll('input[name="gender"]:checked');
  if (!gender.length) {
    alert("You must select male or female");
  }

  const PhonenumberValue = Phonenumber.value;
  var numbers = /^[0-9]+$/;
  if (PhonenumberValue === "" || !PhonenumberValue.match(numbers)) {
    alert("Please Input The Number");
  }

  var dateValue = date.value;

  var tddate = /^(\d{4})(\/|-)(\d{1,2})(\/|-)(\d{1,2})$/;
  if (dateValue === "" || !dateValue.match(tddate)) {
    alert("Please Enter The Date");
  }

  var name1 = Fullname.value;
  var letterNumber = /^[0-9 _]+[A-Z _]+!*$/;
  if (name1 === "" || !name1.match(letterNumber)) {
    alert("Name Not Matching");
  } else {
    alert("Matching");
  }

  var email = emailaddress.value;
  var address =
    /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  if (email === "" || !email.match(address)) {
    alert("Email Address Wrong");
  } else {
    alert("Correct");
  }
  console.log(usernameValue);
  console.log(gender);
  console.log(PhonenumberValue);
  console.log(dateValue);
  console.log(name1);
  console.log(email);
});
function select1() {
  var d = document.getElementById("list");
  var displaytext = d.options[d.selectedIndex].text;
  document.getElementById("txtvalue").value = displaytext;
  alert("selected");
}
function check() {
  var pass = document.getElementById("password");
  if (pass.type === "password") {
    pass.type = "text";
    alert("password set");
  } else {
    pass.type = "password";
  }
}
