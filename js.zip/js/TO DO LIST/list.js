const submit=document.getElementById("submit");
const inputField =document.getElementById("inputField");
const tocontainer =document.getElementById("tocontainer");
const add = () => {
   
    var name1 = inputField.value;
    var push = document.createElement("p");
    push.setAttribute("id","del");
    push.textContent = name1;   
    inputField.value = "";
    tocontainer.appendChild(push,);  
}           
const removeItem = () => {
    var pop = document.querySelectorAll( '#del' );
    var a = pop.length;
    for ( var i = 0; i < a; i++ ) {
        pop[i].addEventListener( 'click', function() {
        this.remove();
    });
}
}



