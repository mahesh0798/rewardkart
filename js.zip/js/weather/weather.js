
var num = 8;

var arr = [1, -1, 3, 2, -7, -5, 11, 6 ]
// var arr1=[];
// var arr2=[];

console.log(arr,arr.length);

let arrLength = arr.length;

for( let i=0; i< arrLength; i++){
    let temp,temp1;
    temp = arr[i];
    console.log(temp)
    
    for(let j=i; j<=i; j++){
        temp1=arr[j];
        console.log(temp1)
        
        // if(Math.sign(arr[i]) === 1 || Math.sign(arr[j]) === -1){
        //     temp = arr[j];
        //     // arr[i] = arr[j];
        //     // arr[j] = temp;
        //     // arr1.push(temp);            
        //     // console.log(arr[j]);
        //     console.log(temp);
        // }else{
        //     temp1 = arr[j]
        //     arr[i] = arr[j];
        //     arr[j] = temp1;
        //     console.log(arr[i],arr[j],temp1)
        // }
        // else if(Math.sign(arr[j]) === -1){
        //     temp1 = arr[j];
        //     console.log(temp1)
        // }
        // else if(temp !== temp1){
        //     // let temp1;
        //     // temp1=arr[j];
        //     // arr2.push(temp1); 
        //     temp2 = arr[j];
        //     arr[i] = arr[j];
        //     arr[j] = temp;
        //     console.log(arr[i],arr[j],temp2)
        // }
         
        // else{
        //     temp1=arr[j];
        // }
        // console.log(temp+" "+ temp1);   
        // else{
        //     temp1 = arr[j]    
        //     console.log(temp1)        
        // // } 

    }    
   
    
}
// var c= arr1.concat(arr2); 
// console.log(c);




// var arr1 = [2, -12, 4, 46, -20, -1],
//     res = arr1.reduce(function(s,a) {
//       a <= 0 ? s.unshift(a) : s.push(a);
//       return s;
//     }, []);
    
//     console.log(res);

    // let index = 0
    // const posnegValue = arr.reduce(s,a =>{
    //     if((Math.sign(s) === 1) <= (Math.sign(a) === -1)){
    //         s.unshift(a)
    //     }else{
    //         s.push(a)
    //     }
    // },[])
    // console.log(posnegValue)