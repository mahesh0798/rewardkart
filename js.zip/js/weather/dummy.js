// const array1 = [1, -6, 2, 3, -4];
// let temp1, temp2, temp,temp3,arr=[];

// for (let i = 0; i < array1.length; i++) {
//   temp = array1[i];

//   console.log(temp);
//   for (let j = i+1; j <= array1.length; j++) {
//     temp1 = array1[j];
//     if (Math.sign(temp) === Math.sign(temp1)) {
//       temp2 = temp1;
//       console.log(temp2);
//     }else{
//         temp3 = temp1;
//       console.log(temp3);
//     }
    
//   }
//   console.log(temp,temp3);
// }
// var str= "HELLO World!"
// console.log(str.toLowerCase())


var str = "the_stealth_warrior" // returns "theStealthWarrior"
var str1 = "A-B-C" // returns "ABC"
var etr = ""
var  regex= /[-_]/g
var str1 = str.split(regex)
console.log(str1);
console.log(str1.length)
for(var i=0;i<str1.length;i++){
    if(str1[i] === 0){
        etr += str1[i].charAt(0).toUpperCase()
    }else{
        etr += str1[i]
    }
    
    console.log(str1[i] == 0,etr)
    // console.log(str1[i].charAt(0).toUpperCase())
    // if(str1[i] === 0){
    //     str1[i].charAt(0).toLowerCase()
    //     console.log(str1[i])
    // }else{
    //     str1[i].charAt(0).toUpperCase()
    //     console.log(str1)
    // }


}