let outputScreen =document.getElementById("output-screen");
 
function display(num)
{
    outputScreen.value +=(num);
}
function del()
 {
    outputScreen.value=outputScreen.value.slice(0,-1)
 }
 function equal(){
    try
    {
        outputScreen.value=eval(outputScreen.value);
    }
    catch(err)
    {
        alert("Invaild");
    }
 }
 function Clear()
 {
    outputScreen.value = "";
 }